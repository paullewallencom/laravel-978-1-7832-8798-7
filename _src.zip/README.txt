There are no source code files in this book.
According to the author, the purpose of the code is not whether they work or not, but it's the strategy behind the code, and how they are coded.